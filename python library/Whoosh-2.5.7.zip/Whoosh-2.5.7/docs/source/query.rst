=============
Query objects
=============

The classes in the :mod:`whoosh.query` module implement *queries* you can run against the index.

TBD.

See :doc:`searching` for how to search the index using query objects.


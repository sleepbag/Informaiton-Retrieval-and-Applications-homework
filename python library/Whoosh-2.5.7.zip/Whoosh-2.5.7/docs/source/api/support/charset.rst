==========================
``support.charset`` module
==========================

.. automodule:: whoosh.support.charset

.. data:: default_charset

    An extensive case- and accent folding charset table.
    Taken from http://speeple.com/unicode-maps.txt

.. autofunction:: charset_table_to_dict

